
export enum ProductCategory {
  TOOTHPASTE = 'Toothpaste',
  BRUSHES = 'Brushes',
  KIDS = 'Kids Products',
  ELECTRIC = 'Electric Accessories'
}

export interface Product {
  id: string;
  name: string;
  category: ProductCategory;
  price: number;
  rating: number;
  reviewCount: number;
  description: string;
  image: string;
}

export interface Course {
  id: string;
  title: string;
  category: 'Faculty' | 'Student' | 'Postgrad';
  duration: string;
  description: string;
}

export interface ResearchPaper {
  id: string;
  title: string;
  author: string;
  date: string;
  abstract: string;
  mediaType: 'Article' | 'Video' | 'Document';
}
