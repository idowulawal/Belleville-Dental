
import React from 'react';
import { COURSES } from '../constants';

const ProfessionalEducation: React.FC = () => {
  return (
    <div className="container mx-auto px-4 fade-in">
      <div className="max-w-4xl mb-16">
        <h2 className="text-4xl font-bold text-slate-900 mb-6">Professional Education</h2>
        <p className="text-lg text-slate-600 leading-relaxed">
          Belleville Dental provides world-class educational opportunities for faculty members, students, 
          and postgraduate researchers. Our curriculum is recognized globally for its focus on 
          evidence-based clinical excellence.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <h3 className="text-2xl font-bold mb-8 flex items-center space-x-3">
            <span className="w-8 h-8 bg-sky-600 text-white rounded-lg flex items-center justify-center text-sm">
              <i className="fas fa-book"></i>
            </span>
            <span>Available Courses</span>
          </h3>
          
          <div className="space-y-6">
            {COURSES.map(course => (
              <div key={course.id} className="bg-white p-8 rounded-2xl border border-slate-100 shadow-sm hover:shadow-md transition-all">
                <div className="flex justify-between items-start mb-4">
                  <span className="px-3 py-1 bg-sky-50 text-sky-600 rounded text-xs font-bold uppercase tracking-widest">
                    {course.category}
                  </span>
                  <span className="text-slate-400 text-sm flex items-center">
                    <i className="far fa-clock mr-2"></i> {course.duration}
                  </span>
                </div>
                <h4 className="text-xl font-bold mb-3">{course.title}</h4>
                <p className="text-slate-600 mb-6">{course.description}</p>
                <button className="bg-sky-600 hover:bg-sky-700 text-white px-6 py-2 rounded font-bold transition-all text-sm">
                  Enroll Now
                </button>
              </div>
            ))}
          </div>
        </div>

        <div className="space-y-8">
          <div className="bg-slate-900 text-white p-8 rounded-2xl shadow-xl">
            <h3 className="text-xl font-bold mb-4">Resource Center</h3>
            <p className="text-slate-400 text-sm mb-6">Access private documents, faculty notes, and student guidelines.</p>
            <ul className="space-y-4">
              <li>
                <a href="#" className="flex items-center group">
                  <i className="far fa-file-pdf text-red-400 mr-3 text-lg"></i>
                  <span className="group-hover:text-sky-400 transition-colors">Clinical Guidelines 2024</span>
                </a>
              </li>
              <li>
                <a href="#" className="flex items-center group">
                  <i className="far fa-file-word text-blue-400 mr-3 text-lg"></i>
                  <span className="group-hover:text-sky-400 transition-colors">Faculty Handbook</span>
                </a>
              </li>
              <li>
                <a href="#" className="flex items-center group">
                  <i className="far fa-file-powerpoint text-orange-400 mr-3 text-lg"></i>
                  <span className="group-hover:text-sky-400 transition-colors">Lecture Materials (Zip)</span>
                </a>
              </li>
            </ul>
          </div>

          <div className="bg-sky-50 p-8 rounded-2xl border border-sky-100">
            <h3 className="text-xl font-bold text-sky-900 mb-4">Case Studies</h3>
            <p className="text-sky-700/70 text-sm mb-6">Real-world clinical scenarios analyzed by our lead practitioners.</p>
            <button className="text-sky-700 font-bold text-sm hover:underline">
              View Media Library →
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProfessionalEducation;
