
import React from 'react';

const PatientEducation: React.FC = () => {
  const tips = [
    {
      title: 'The 2-2-2 Rule',
      content: 'Brush twice a day, for two minutes each time, and visit your dentist twice a year.',
      icon: 'fa-tooth'
    },
    {
      title: 'Floss First',
      content: 'Flossing before brushing helps loosen food particles, making your brushing more effective.',
      icon: 'fa-teeth'
    },
    {
      title: 'Watch the Acid',
      content: 'Frequent consumption of acidic drinks can erode tooth enamel over time.',
      icon: 'fa-glass-whiskey'
    }
  ];

  return (
    <div className="container mx-auto px-4 fade-in">
      <div className="text-center max-w-2xl mx-auto mb-16">
        <h2 className="text-4xl font-bold text-slate-900 mb-6">Patient Education</h2>
        <p className="text-slate-600">
          Your journey to a healthier smile starts with understanding your oral health. 
          Discover expert advice and preventive care tips below.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-20">
        {tips.map((tip, idx) => (
          <div key={idx} className="bg-white p-8 rounded-2xl border border-slate-100 text-center hover:shadow-lg transition-all">
            <div className="w-12 h-12 bg-sky-100 rounded-full flex items-center justify-center text-sky-600 mx-auto mb-6">
              <i className={`fas ${tip.icon}`}></i>
            </div>
            <h3 className="text-xl font-bold mb-3">{tip.title}</h3>
            <p className="text-slate-500 text-sm leading-relaxed">{tip.content}</p>
          </div>
        ))}
      </div>

      <div className="bg-white rounded-3xl overflow-hidden shadow-sm border border-slate-100 flex flex-col lg:flex-row">
        <div className="lg:w-1/2">
          <img 
            src="https://picsum.photos/seed/patient/800/600" 
            alt="Patient Care" 
            className="w-full h-full object-cover"
          />
        </div>
        <div className="lg:w-1/2 p-12">
          <h3 className="text-3xl font-bold mb-8">Common Oral Problems</h3>
          
          <div className="space-y-8">
            <div className="flex space-x-6">
              <div className="flex-shrink-0 w-10 h-10 bg-red-50 rounded flex items-center justify-center text-red-500 font-bold">1</div>
              <div>
                <h4 className="font-bold text-lg mb-2">Gingivitis</h4>
                <p className="text-slate-500 text-sm">Inflammation of the gums caused by plaque buildup. Characterized by redness and bleeding during brushing.</p>
              </div>
            </div>
            
            <div className="flex space-x-6">
              <div className="flex-shrink-0 w-10 h-10 bg-red-50 rounded flex items-center justify-center text-red-500 font-bold">2</div>
              <div>
                <h4 className="font-bold text-lg mb-2">Cavities (Dental Caries)</h4>
                <p className="text-slate-500 text-sm">Permanently damaged areas in the hard surface of your teeth that develop into tiny openings or holes.</p>
              </div>
            </div>

            <div className="flex space-x-6">
              <div className="flex-shrink-0 w-10 h-10 bg-red-50 rounded flex items-center justify-center text-red-500 font-bold">3</div>
              <div>
                <h4 className="font-bold text-lg mb-2">Enamel Erosion</h4>
                <p className="text-slate-500 text-sm">The loss of the outer protective layer of your teeth, often caused by acid in food and drink.</p>
              </div>
            </div>
          </div>
          
          <button className="mt-12 w-full bg-slate-900 text-white py-4 rounded-xl font-bold hover:bg-slate-800 transition-colors">
            Book a Virtual Consultation
          </button>
        </div>
      </div>
    </div>
  );
};

export default PatientEducation;
