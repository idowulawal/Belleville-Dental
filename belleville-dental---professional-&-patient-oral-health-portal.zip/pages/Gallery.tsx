
import React from 'react';

const Gallery: React.FC = () => {
  const images = Array.from({ length: 9 }).map((_, i) => ({
    id: i,
    url: `https://picsum.photos/seed/dental-gal-${i}/800/800`,
    title: `Gallery Image ${i + 1}`,
    desc: 'Our state-of-the-art facilities and procedures.'
  }));

  return (
    <div className="container mx-auto px-4 fade-in">
      <div className="text-center mb-16">
        <h2 className="text-4xl font-bold text-slate-900 mb-4">Visual Gallery</h2>
        <p className="text-slate-600">A look inside our world-class clinics and labs.</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {images.map(img => (
          <div key={img.id} className="group relative overflow-hidden rounded-2xl aspect-square">
            <img 
              src={img.url} 
              alt={img.title}
              className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-900/80 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex flex-col justify-end p-8 text-white">
              <h4 className="font-bold text-lg mb-1">{img.title}</h4>
              <p className="text-slate-300 text-sm">{img.desc}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Gallery;
