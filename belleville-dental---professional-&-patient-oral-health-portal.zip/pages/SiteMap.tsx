
import React from 'react';
import { Link } from 'react-router-dom';

const SiteMap: React.FC = () => {
  const sections = [
    {
      title: 'Education',
      links: [
        { label: 'Professional Courses', path: '/professional-education' },
        { label: 'Faculty Resources', path: '/professional-education' },
        { label: 'Case Studies', path: '/professional-education' },
        { label: 'Patient Education', path: '/patient-education' },
        { label: 'Preventive Care', path: '/patient-education' },
      ]
    },
    {
      title: 'Research & Products',
      links: [
        { label: 'Research Articles', path: '/research' },
        { label: 'Media Library', path: '/research' },
        { label: 'All Products', path: '/products' },
        { label: 'Product Ratings', path: '/products' },
      ]
    },
    {
      title: 'Company',
      links: [
        { label: 'About Belleville', path: '/about-us' },
        { label: 'Contact Us', path: '/contact-us' },
        { label: 'Photo Gallery', path: '/gallery' },
        { label: 'Support Portal', path: '/contact-us' },
      ]
    }
  ];

  return (
    <div className="container mx-auto px-4 fade-in">
      <h2 className="text-4xl font-bold text-slate-900 mb-12">Site Map</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
        {sections.map(section => (
          <div key={section.title}>
            <h3 className="text-sky-600 font-bold text-xs uppercase tracking-[0.2em] mb-6">{section.title}</h3>
            <ul className="space-y-4">
              {section.links.map(link => (
                <li key={link.label}>
                  <Link to={link.path} className="text-slate-600 hover:text-sky-600 transition-colors font-medium">
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
      
      <div className="mt-20 p-12 bg-slate-50 rounded-3xl border border-slate-100 text-center">
        <p className="text-slate-400 text-sm">Need help finding something specific? Contact our support team directly.</p>
        <Link to="/contact-us" className="inline-block mt-4 font-bold text-sky-600 hover:underline">Support Center →</Link>
      </div>
    </div>
  );
};

export default SiteMap;
