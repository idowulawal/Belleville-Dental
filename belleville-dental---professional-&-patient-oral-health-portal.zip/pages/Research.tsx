
import React from 'react';
import { RESEARCH } from '../constants';

const Research: React.FC = () => {
  return (
    <div className="container mx-auto px-4 fade-in">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-16 gap-4">
        <div>
          <h2 className="text-4xl font-bold text-slate-900 mb-2">Research Library</h2>
          <p className="text-slate-600">Peer-reviewed studies and media documentation from Belleville Labs.</p>
        </div>
        <div className="flex space-x-4">
          <div className="flex items-center bg-white border border-slate-200 rounded-lg px-4 py-2">
            <i className="fas fa-search text-slate-400 mr-2"></i>
            <input type="text" placeholder="Search research..." className="outline-none text-sm w-48" />
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {RESEARCH.map(item => (
          <div key={item.id} className="bg-white p-8 rounded-2xl border border-slate-100 shadow-sm hover:shadow-xl transition-all flex flex-col">
            <div className="flex justify-between items-start mb-6">
              <span className={`px-2 py-1 rounded text-[10px] font-bold uppercase tracking-widest ${
                item.mediaType === 'Video' ? 'bg-purple-100 text-purple-600' : 'bg-emerald-100 text-emerald-600'
              }`}>
                {item.mediaType}
              </span>
              <span className="text-slate-400 text-xs">{item.date}</span>
            </div>
            
            <h3 className="text-xl font-bold mb-2">{item.title}</h3>
            <p className="text-slate-400 text-sm font-medium mb-4">By {item.author}</p>
            <p className="text-slate-600 text-sm leading-relaxed mb-8 flex-grow">
              {item.abstract}
            </p>
            
            <div className="flex items-center justify-between mt-auto pt-6 border-t border-slate-50">
              <button className="flex items-center text-sky-600 font-bold text-sm hover:underline">
                <i className={`${item.mediaType === 'Video' ? 'fas fa-play' : 'fas fa-file-alt'} mr-2`}></i>
                {item.mediaType === 'Video' ? 'Watch Video' : 'Read Article'}
              </button>
              <button className="text-slate-400 hover:text-sky-600 transition-colors">
                <i className="fas fa-bookmark"></i>
              </button>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-20 bg-slate-900 rounded-3xl p-12 text-center text-white">
        <h3 className="text-3xl font-bold mb-4">Contribute to Science</h3>
        <p className="text-slate-400 max-w-2xl mx-auto mb-8">
          Are you a researcher looking to collaborate? Belleville Dental provides grants and 
          laboratory facilities for groundbreaking studies in restorative dentistry.
        </p>
        <button className="bg-white text-slate-900 px-8 py-3 rounded-lg font-bold hover:bg-sky-50 transition-colors">
          Collaboration Portal
        </button>
      </div>
    </div>
  );
};

export default Research;
