
import React, { useState, useEffect } from 'react';
import { HashRouter as Router, Routes, Route, Link, useLocation } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import Ticker from './components/Ticker';
import ProfessionalEducation from './pages/ProfessionalEducation';
import PatientEducation from './pages/PatientEducation';
import Research from './pages/Research';
import Products from './pages/Products';
import Gallery from './pages/Gallery';
import SiteMap from './pages/SiteMap';
import AboutUs from './pages/AboutUs';
import ContactUs from './pages/ContactUs';
import Home from './pages/Home';

const App: React.FC = () => {
  return (
    <Router>
      <div className="flex flex-col min-h-screen">
        <Header />
        
        <main className="flex-grow pt-32 pb-16">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/professional-education" element={<ProfessionalEducation />} />
            <Route path="/patient-education" element={<PatientEducation />} />
            <Route path="/research" element={<Research />} />
            <Route path="/products" element={<Products />} />
            <Route path="/gallery" element={<Gallery />} />
            <Route path="/sitemap" element={<SiteMap />} />
            <Route path="/about-us" element={<AboutUs />} />
            <Route path="/contact-us" element={<ContactUs />} />
          </Routes>
        </main>

        <Footer />
        <Ticker />
      </div>
    </Router>
  );
};

export default App;
